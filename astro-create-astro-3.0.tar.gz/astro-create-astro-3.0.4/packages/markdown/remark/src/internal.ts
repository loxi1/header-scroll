export {
	InvalidAstroDataError,
	safelyGetAstroData,
	toRemarkInitializeAstroData,
} from './frontmatter-injection.js';

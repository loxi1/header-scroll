export const mockRenderMarkdownParams = {
	contentDir: new URL('file:///src/content/'),
};

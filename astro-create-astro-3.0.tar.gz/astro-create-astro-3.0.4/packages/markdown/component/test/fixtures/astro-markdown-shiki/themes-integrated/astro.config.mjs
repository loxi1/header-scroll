export default {
	markdown: {
		syntaxHighlight: 'shiki',
		shikiConfig: { theme: 'github-light' },
	},
}

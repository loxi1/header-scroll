export default {
	markdown: {
		syntaxHighlight: 'shiki',
		shikiConfig: { wrap: null },
	},
}

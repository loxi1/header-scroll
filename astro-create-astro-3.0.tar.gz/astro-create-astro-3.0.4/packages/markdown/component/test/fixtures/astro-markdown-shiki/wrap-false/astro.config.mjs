export default {
	markdown: {
		syntaxHighlight: 'shiki',
		shikiConfig: { wrap: false },
	},
}

export default {
	markdown: {
		syntaxHighlight: 'shiki',
		shikiConfig: { wrap: true },
	},
}

export default {
	markdown: {
		syntaxHighlight: 'shiki',
	},
}

import { h } from 'preact';

export default function ({ name }) {
  return <div id="test">Hello {name}</div>;
}

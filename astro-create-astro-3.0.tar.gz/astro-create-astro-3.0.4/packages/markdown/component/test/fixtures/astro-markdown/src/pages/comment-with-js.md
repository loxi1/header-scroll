<!--
HTML comments with */ inside!
-->

<!--
```js
/**
 * It even works inside nested fenced code blocks!
 */
function test() {
	/* Yay */
	return 'Nice!';
}
```
-->

```
<!-- HTML comments in code fence -->
```

`<!-- HTML comments in code -->`

# It still works!

This should have `nospace` around it.

This should have <code class="custom-class">nospace</code> around it.

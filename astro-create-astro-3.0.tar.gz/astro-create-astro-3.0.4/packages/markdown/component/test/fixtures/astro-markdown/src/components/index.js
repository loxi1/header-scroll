import Counter from './Counter';

export default {
	Counter
}

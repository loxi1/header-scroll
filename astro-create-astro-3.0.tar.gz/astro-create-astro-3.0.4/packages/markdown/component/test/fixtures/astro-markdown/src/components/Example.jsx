import { h } from 'preact';

export default function () {
  return <div id="test">Testing</div>;
}

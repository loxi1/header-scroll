---
title: My Blog Post
layout: ../layouts/content.astro
---

## Title

Hello world

With this in the body ---

## Another

more content
<script>
	let cool = false
</script>

<button on:click={() => cool = true}>This is cool right? {cool}</button>

<style>
	button {
		background: green;
	}
</style>

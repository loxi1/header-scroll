export function alert(...messages: any[]) {
	console.log(...messages)
}

declare module 'node:*'
declare module '@ungap/structured-clone/esm/index.js'
declare module '@ungap/structured-clone/esm/deserialize.js'
declare module '@ungap/structured-clone/esm/serialize.js'

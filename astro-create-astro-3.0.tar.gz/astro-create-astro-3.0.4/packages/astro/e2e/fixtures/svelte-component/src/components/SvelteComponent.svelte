<script lang="ts">
	export let id: string;
</script>

<div {id}>Framework client:only component</div>

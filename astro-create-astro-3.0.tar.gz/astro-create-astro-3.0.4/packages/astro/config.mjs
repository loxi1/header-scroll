export { defineConfig, getViteConfig } from './dist/config/index.js';
